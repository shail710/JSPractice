//import { expect } from 'chai';
//import * as helpers from './helpers';
import * as funcs from './ch4-q01';

for (let key in funcs) {
//  let func = funcs[key];

  describe('ch4-q01: ' + key, function() {
    // TODO
  });

}
