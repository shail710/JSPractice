export class Caller {
  constructor(id, nm) {
    this.name = nm;
    this.userId = id;
  }
}
